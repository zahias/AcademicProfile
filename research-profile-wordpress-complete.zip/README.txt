==========================================
Research Profile Platform for WordPress
Complete Package
==========================================

This package contains EVERYTHING needed to run Research Profile Platform on WordPress.
No separate backend hosting required!

CONTENTS:
---------
1. theme/        - WordPress theme (frontend)
2. plugin/       - WordPress plugin (backend functionality)

WHAT'S INCLUDED:
----------------
✅ React frontend application
✅ PHP backend (replaces Node.js)
✅ OpenAlex API integration
✅ WordPress REST API endpoints
✅ Database tables (automatic creation)
✅ Admin interface
✅ CV upload functionality
✅ Data caching system

INSTALLATION STEPS:
-------------------

STEP 1: Install the Plugin
1. Go to WordPress Admin → Plugins → Add New → Upload Plugin
2. Choose: plugin/ folder (or zip the plugin/ folder first)
3. Click "Install Now"
4. Click "Activate"

STEP 2: Install the Theme
1. Go to WordPress Admin → Appearance → Themes → Add New → Upload Theme
2. Choose: theme/ folder (or zip the theme/ folder first)
3. Click "Install Now"
4. Click "Activate"

STEP 3: Add Your First Profile
1. Go to WordPress Admin → Research Profiles
2. Click "Add New"
3. Enter an OpenAlex ID (e.g., A5056485484)
4. Click "Add Profile & Sync Data"

STEP 4: View Your Site
Visit your WordPress site to see the research profile interface!

IMPORTANT NOTES:
----------------

✅ Everything runs on WordPress - no separate server needed
✅ Uses WordPress authentication - no API tokens required
✅ CVs stored in WordPress Media Library
✅ Data cached in WordPress database (MySQL)
✅ Compatible with any WordPress hosting

SYSTEM REQUIREMENTS:
--------------------
- WordPress 5.8+
- PHP 7.4+
- MySQL 5.7+

FINDING OPENALEX IDS:
---------------------
1. Go to https://openalex.org/
2. Search for a researcher
3. Copy their author ID (starts with A, like A5056485484)

API ENDPOINTS:
--------------
Base URL: https://your-site.com/wp-json/research-profile/v1/

Public:
  GET /researcher/{openalex_id}/data
  GET /openalex/search/{openalex_id}

Admin (requires WordPress login):
  POST /admin/researcher/profile
  PUT /admin/researcher/profile/{openalex_id}
  POST /admin/researcher/{openalex_id}/sync
  POST /admin/researcher/{openalex_id}/upload-cv

FEATURES:
---------
✅ Automatic OpenAlex data synchronization
✅ Publications, topics, and affiliations
✅ Citation metrics and h-index
✅ Public researcher profiles
✅ Admin dashboard for management
✅ CV/resume uploads
✅ Data caching for performance

TROUBLESHOOTING:
----------------

Problem: Plugin or theme won't activate
Solution: Check WordPress and PHP versions meet requirements

Problem: Can't see profiles after adding
Solution: Click "Sync" button in admin to refresh data from OpenAlex

Problem: OpenAlex sync fails
Solution: Check that your server can make outbound HTTPS requests to api.openalex.org

Problem: 404 errors on REST API endpoints
Solution: Go to Settings → Permalinks and click "Save Changes" to flush rewrite rules

SUPPORT:
--------
For issues or questions, check the README files in theme/ and plugin/ folders.

==========================================
Ready to install? Follow the steps above!
==========================================
